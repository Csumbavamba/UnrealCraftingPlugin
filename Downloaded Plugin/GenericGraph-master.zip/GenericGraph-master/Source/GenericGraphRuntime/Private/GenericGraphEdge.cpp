#include "GenericGraphEdge.h"

UGenericGraphEdge::UGenericGraphEdge()
{

}

UGenericGraphEdge::~UGenericGraphEdge()
{

}

UGenericGraph* UGenericGraphEdge::GetGraph() const
{
	return Graph;
}
